import os
import zipfile
import subprocess

root = os.getcwd()
zip_path = os.path.join(root, "remediation_round2.zip")

# Get modified and untracked files
files_to_zip = []

try:
    diff_out = subprocess.check_output(["git", "diff", "--name-only", "HEAD~1"], cwd=root).decode("utf-8")
    for line in diff_out.strip().split("\n"):
        line = line.strip().strip('"')
        if line and not line.endswith(".zip"):
            files_to_zip.append(line)
except Exception as e:
    print(f"git diff error: {e}")

status_out = subprocess.check_output(["git", "status", "--porcelain"], cwd=root).decode("utf-8")
for line in status_out.strip().split("\n"):
    if not line:
        continue
    fname = line[3:].strip().strip('"')
    if fname.endswith(".zip") or fname.startswith("build/") or fname.startswith("app/build/"):
        continue
    full = os.path.join(root, fname)
    if os.path.isdir(full):
        for r, _, fs in os.walk(full):
            for f in fs:
                rel = os.path.relpath(os.path.join(r, f), root).replace("\\", "/")
                files_to_zip.append(rel)
    else:
        files_to_zip.append(fname.replace("\\", "/"))

files_to_zip = sorted(set(files_to_zip))
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for f in files_to_zip:
        full = os.path.join(root, f)
        if os.path.isfile(full):
            z.write(full, f)

print(f"Clean archive created: {zip_path} with {len(files_to_zip)} files")
